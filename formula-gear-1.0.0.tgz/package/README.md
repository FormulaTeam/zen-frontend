# Formula Gear

**Formula Gear** is the core shared contracts library for the Formula ecosystem. It standardizes types, validation schemas, error codes, and logic flows between the **Formula Engine** (Backend) and **Formula Cockpit** (Frontend).

## 🏗️ Architecture & Error Handling

**Note: This library is distributed as pure ES Modules (ESM).** Consuming projects must be configured to support ESM (e.g. `"type": "module"` or using a bundler like Webpack/Vite).

The Formula ecosystem strictly adheres to **Functional Error Handling** principles (using `neverthrow`). While this library (`formula-gear`) provides the _types_ and _codes_, the consuming services (like the Engine) follow these strict implementation rules.

### 1. The `Result` Pattern

Services and repositories in the ecosystem must return `Result<T, E>` types. They do **not** throw exceptions for business logic (e.g., "User not found"). Exceptions are reserved for catastrophic failures.

### 2. Error Hierarchy

`formula-gear` defines the global error interface that connects the ecosystem:

- **`FormulaError`**: The global error interface.
  - `code`: A standardized code from `formulaErrorCode` (e.g., `formulaErrorCode.RESOURCE_NOT_FOUND`).
  - `message`: A human-readable message.
  - `meta`: Optional metadata.

- **`DomainError`** (Internal to Services): Modules define their own specific errors (e.g., `AuthError`, `InvalidRefreshToken`) which are then mapped to `FormulaError`.

### 3. The Mapping Pipeline

Errors flow through a strict mapping pipeline to ensure consistency:

1.  **Repository/Infra Layer**: Catches external errors (e.g., Database constraints) and maps them to **Domain Errors**.
2.  **Service/Domain Layer**: Returns **Domain Errors** (e.g., `AuthError`).
3.  **Controller Layer**:
    - Unwraps the `Result`.
    - **Success**: Returns the DTO.
    - **Failure**: Maps `Domain Error` -> `Formula Error` -> `HTTP Exception`.

## 🛠️ Implementation Guide

### Defining Shared Contracts

#### 1. Error Codes (`src/errors/codes.ts`)

Add new error codes here when a new business scenario arises that requires a specific client-side reaction.

```typescript
export const formulaErrorCode = {
  // ... existing codes
  PAYMENT_FAILED: 'PAYMENT_FAILED',
} as const;
```

#### 2. HTTP Mapping (`src/errors/formula-to-http.ts`)

Map the new error code to an appropriate HTTP status.

```typescript
[formulaErrorCode.PAYMENT_FAILED]: StatusCodes.PAYMENT_REQUIRED,
```

#### 3. DTOs & Validation (`src/validators`)

Use `zod` to create schemas that represent the shared contracts. These schemas serve as the single source of truth for both the backend and frontend.

**Formula Gear (Shared Schema):**

```typescript
import { z } from 'zod';

export const CreateItemSchema = z.object({
  name: z.string().describe('The name of the item'),
});
```

**Formula Engine (Backend):**
The NestJS backend consumes these schemas using `nestjs-zod` to create DTO classes for validation pipes and Swagger generation.

```typescript
import { createZodDto } from 'nestjs-zod';
import { CreateItemSchema } from 'formula-gear';

export class CreateItemDto extends createZodDto(CreateItemSchema) {}
```

**Formula Cockpit (Frontend):**
The React frontend uses standard `zod` inference for types and libraries like `@hookform/resolvers/zod` for form validation.

```typescript
import { z } from 'zod';
import { CreateItemSchema } from 'formula-gear';

export type CreateItemType = z.infer<typeof CreateItemSchema>;
```

## 📦 Installation

```bash
npm install formula-gear@github:raskinbarak/formula-gear
```

## 🤝 Contributing

Refer to [STYLE.md](./STYLE.md) for detailed naming and formatting guidelines, including our [Git Commit Guidelines](./STYLE.md#7-git-commit-guidelines).
